"""HUD رندرشده با SDL3/C++؛ بدون وابستگی به pygame یا فایل تصویر خارجی."""
import conster
from cppfuncs import DrawObj, GetRenderer, LoadTexture


class HUD:
    """نمایش نوار سلامتی و گرسنگی در مختصات ثابت صفحه."""

    def __init__(self):
        self.renderer = GetRenderer()
        if not self.renderer:
            raise RuntimeError("HUD requires an initialized SDL renderer")

        # LoadTexture یک تکسچر تک‌رنگ می‌سازد؛ این شناسه‌ها بعد از Texture.init هستند.
        self.panel = LoadTexture(self.renderer, 18, 22, 30, 225)
        self.track = LoadTexture(self.renderer, 65, 70, 78, 255)
        self.health_color = LoadTexture(self.renderer, 220, 45, 48, 255)
        self.hunger_color = LoadTexture(self.renderer, 225, 155, 35, 255)
        self.white = LoadTexture(self.renderer, 235, 240, 245, 255)

        self._textures = (
            self.panel, self.track, self.health_color,
            self.hunger_color, self.white,
        )
        if any(texture < 0 for texture in self._textures):
            raise RuntimeError("Could not create HUD textures")

    @staticmethod
    def _clamp(value, low=0.0, high=100.0):
        try:
            value = float(value)
        except (TypeError, ValueError):
            return low
        return max(low, min(high, value))

    def _rect(self, texture, x, y, width, height):
        if width <= 0 or height <= 0:
            return
        DrawObj(
            self.renderer,
            float(x), float(y), float(width), float(height),
            int(texture),
        )

    def _text(self, value, x, y, scale=2):
        """فونت پیکسلی کوچک؛ فقط ارقام و حروف موردنیاز HUD."""
        glyphs = {
            "0": ("111", "101", "101", "101", "111"),
            "1": ("010", "110", "010", "010", "111"),
            "2": ("111", "001", "111", "100", "111"),
            "3": ("111", "001", "111", "001", "111"),
            "4": ("101", "101", "111", "001", "001"),
            "5": ("111", "100", "111", "001", "111"),
            "6": ("111", "100", "111", "101", "111"),
            "7": ("111", "001", "010", "010", "010"),
            "8": ("111", "101", "111", "101", "111"),
            "9": ("111", "101", "111", "001", "111"),
            "H": ("101", "101", "111", "101", "101"),
            "P": ("110", "101", "110", "100", "100"),
            "F": ("111", "100", "110", "100", "100"),
            "O": ("111", "101", "101", "101", "111"),
            "D": ("110", "101", "101", "101", "110"),
        }
        cursor = x
        for char in str(value).upper():
            glyph = glyphs.get(char)
            if glyph is None:
                cursor += 4 * scale
                continue
            for row, line in enumerate(glyph):
                for col, pixel in enumerate(line):
                    if pixel == "1":
                        self._rect(
                            self.white,
                            cursor + col * scale,
                            y + row * scale,
                            scale,
                            scale,
                        )
            cursor += 4 * scale

    def draw(self, player):
        if player is None:
            return

        status = player.getStatus()
        health = self._clamp(status.get("health", 100))
        hungry = self._clamp(status.get("hungry", 0))

        # Panel and tracks are drawn in screen-space, so camera movement
        # never moves the HUD with the world.
        x, y = 14, 14
        self._rect(self.panel, x, y, 224, 72)

        self._text("HP", x + 10, y + 10)
        self._rect(self.track, x + 48, y + 10, 164, 12)
        self._rect(self.health_color, x + 48, y + 10, 164 * health / 100, 12)
        self._text(int(round(health)), x + 48, y + 29)

        self._text("FOOD", x + 10, y + 49)
        self._rect(self.track, x + 48, y + 48, 164, 12)
        self._rect(self.hunger_color, x + 48, y + 48, 164 * hungry / 100, 12)
