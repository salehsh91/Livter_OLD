"""Livter HUD rendered through the existing SDL3 renderer."""
from cppfuncs import DrawObj, GetRenderer
from texture import Texture
from conster import camdirline


class HUD:
    SLOT_COUNT = 12
    ICON_SIZE = 10
    ICON_STEP = 12
    SLOT_SIZE = 38
    SLOT_GAP = 4

    def __init__(self, player, camera, inventory=None):
        self.player = player
        self.camera = camera
        self.inventory = inventory
        self.status = player.getStatus()

    def update(self, status=None):
        self.status = status if status is not None else self.player.getStatus()

    @staticmethod
    def _draw(renderer, x, y, w, h, texture):
        if texture is None or int(texture) < 0:
            return
        DrawObj(renderer, float(x), float(y), float(w), float(h), int(texture))

    def _draw_status(self, renderer):
        health = max(0, min(100, int(self.status.get("health", 0))))
        hungry = max(0, min(100, int(self.status.get("hungry", 0))))
        health_units = (health + 9) // 10
        hungry_units = (hungry + 9) // 10

        # Keep the original HUD's two vertical columns and spacing.
        for i in range(10):
            y = 10 + i * self.ICON_STEP
            self._draw(renderer, 20, y, self.ICON_SIZE, self.ICON_SIZE,
                       Texture.health if i < health_units else Texture.stone)
            self._draw(renderer, 40, y, self.ICON_SIZE, self.ICON_SIZE,
                       Texture.hungry if i < hungry_units else Texture.stone)

    @staticmethod
    def _item_texture(item):
        if item is None:
            return None
        if isinstance(item, int):
            return item
        name = getattr(item, "name", item)
        if not isinstance(name, str):
            return None
        return getattr(Texture, name, None)

    def _draw_inventory(self, renderer):
        width = self.camera.width
        height = self.camera.height
        total_width = self.SLOT_COUNT * self.SLOT_SIZE + (self.SLOT_COUNT - 1) * self.SLOT_GAP
        start_x = (width - total_width) / 2
        y = height - self.SLOT_SIZE - 12
        slots = self.inventory.getinvertory() if self.inventory else {}

        for index in range(self.SLOT_COUNT):
            x = start_x + index * (self.SLOT_SIZE + self.SLOT_GAP)
            entry = slots.get(index + 1)
            active = bool(entry[2]) if entry and len(entry) > 2 else False
            border = Texture.health if active else Texture.stone
            # Background and a thin active border, all in screen-space.
            self._draw(renderer, x, y, self.SLOT_SIZE, self.SLOT_SIZE, Texture.stone)
            if active:
                self._draw(renderer, x, y, self.SLOT_SIZE, 3, border)
                self._draw(renderer, x, y + self.SLOT_SIZE - 3, self.SLOT_SIZE, 3, border)
                self._draw(renderer, x, y, 3, self.SLOT_SIZE, border)
                self._draw(renderer, x + self.SLOT_SIZE - 3, y, 3, self.SLOT_SIZE, border)
            if entry:
                texture = self._item_texture(entry[0])
                if texture is not None:
                    self._draw(renderer, x + 6, y + 6, self.SLOT_SIZE - 12,
                               self.SLOT_SIZE - 12, texture)

    def _draw_direction(self, renderer):
        dx, dy = self.player.direction
        length = (dx * dx + dy * dy) ** 0.5
        if length <= 0:
            return
        dx /= length
        dy /= length
        start_x = self.player.world_x + self.player.width / 2 + self.camera.x
        start_y = self.player.world_y + self.player.height / 2 + self.camera.y
        steps = max(1, int(camdirline / 4))
        for i in range(1, steps + 1):
            x = start_x + dx * (camdirline * i / steps) - 2
            y = start_y + dy * (camdirline * i / steps) - 2
            self._draw(renderer, x, y, 4, 4, Texture.stone)

    def draw(self):
        renderer = GetRenderer()
        if not renderer:
            return
        self._draw_status(renderer)
        self._draw_inventory(renderer)
        self._draw_direction(renderer)


# Compatibility with code that imported the old class name.
HealthBar = HUD
