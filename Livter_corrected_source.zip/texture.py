from cppfuncs import GetRenderer, LoadTexture

class Texture:
    # IDs are deliberately fixed to match BLOCK_IDS in blockitem.py
    air = 0
    grass = 1
    stone = 2
    water = 3
    sand = 4
    plank = 5
    oak = 6
    leaves = 7
    health = 8
    hungry = 9
    npc1 = 10
    _initialized = False

    @classmethod
    def init(cls):
        if cls._initialized:
            return
        renderer = GetRenderer()
        if not renderer:
            raise RuntimeError("SDL renderer is not initialized")

        # Reserve texture ID 0 for air (transparent).
        ids = [
            LoadTexture(renderer, 0, 0, 0, 0),
            LoadTexture(renderer, 60, 160, 60, 255),
            LoadTexture(renderer, 120, 120, 120, 255),
            LoadTexture(renderer, 50, 90, 200, 255),
            LoadTexture(renderer, 220, 200, 120, 255),
            LoadTexture(renderer, 150, 100, 50, 255),
            LoadTexture(renderer, 105, 75, 35, 255),
            LoadTexture(renderer, 45, 135, 45, 210),
            LoadTexture(renderer, 220, 40, 40, 255),
            LoadTexture(renderer, 220, 150, 30, 255),
            LoadTexture(renderer, 255, 0, 0, 255),
        ]
        expected = list(range(len(ids)))
        if ids != expected:
            raise RuntimeError(
                f"SDL texture IDs are not sequential: expected {expected}, got {ids}"
            )
        (cls.air, cls.grass, cls.stone, cls.water, cls.sand,
         cls.plank, cls.oak, cls.leaves, cls.health,
         cls.hungry, cls.npc1) = ids
        cls._initialized = True
