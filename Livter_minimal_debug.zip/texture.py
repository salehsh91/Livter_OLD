import os
from cppfuncs import *
from conster import *

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ASSETS_DIR = os.path.join(BASE_DIR, "assets")






class Texturep:
    pass

class Texture:
    empty = -2
    grass = water = stone = sand = plank = health = hungry = oak = leaves = -2
    npc1 = -2

    
    
    @classmethod
    def init(cls):
        renderer = GetRenderer()
        if not renderer:
            raise RuntimeError("SDL renderer is not initialized")

        # The C++ chunk renderer treats texture ID 0 as an empty cell.
        cls.empty = LoadTexture(renderer, 0, 0, 0, 0)

        cls.grass = LoadImageTexture(
            renderer, os.fsencode(os.path.join(ASSETS_DIR, "grass.png"))
        )
        cls.water = LoadImageTexture(
            renderer, os.fsencode(os.path.join(ASSETS_DIR, "water.png"))
        )
        cls.stone = LoadImageTexture(
            renderer, os.fsencode(os.path.join(ASSETS_DIR, "stone.png"))
        )
        cls.sand = LoadImageTexture(
            renderer, os.fsencode(os.path.join(ASSETS_DIR, "sand.png"))
        )
        cls.plank = LoadImageTexture(
            renderer, os.fsencode(os.path.join(ASSETS_DIR, "plank.png"))
        )
        cls.health = LoadImageTexture(
            renderer, os.fsencode(os.path.join(ASSETS_DIR, "health.png"))
        )
        cls.hungry = LoadImageTexture(
            renderer, os.fsencode(os.path.join(ASSETS_DIR, "hungry.png"))
        )
        cls.oak = LoadImageTexture(
            renderer, os.fsencode(os.path.join(ASSETS_DIR, "oak.png"))
        )
        cls.leaves = LoadImageTexture(
            renderer, os.fsencode(os.path.join(ASSETS_DIR, "leaves.png"))
        )

        cls.npc1 = LoadTexture(renderer, 255, 0, 0, 255)

        return all(texture_id >= 0 for texture_id in (
            cls.empty, cls.grass, cls.water, cls.stone, cls.sand, cls.plank,
            cls.health, cls.hungry, cls.oak, cls.leaves, cls.npc1
        ))
