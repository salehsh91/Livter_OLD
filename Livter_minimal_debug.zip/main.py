import random
import ctypes
import conster
from cppfuncs import *


# SDL must be initialized before querying window dimensions or loading textures.
if Init() != 0:
    raise RuntimeError("SDL initialization failed")

try:
    width, height = getWinSize()
    if width <= 0 or height <= 0:
        raise RuntimeError(f"Invalid SDL window size: {width}x{height}")

    conster.WIDTH = width
    conster.HEIGHT = height

    # Import these after setting WIDTH/HEIGHT because the existing modules
    # import those values from conster when they are loaded.
    from contoroler import Contoroler_Key
    from npc import NPC
    from texture import Texture
    from world import World

    MAX_ENTITIES = 20000
    EntityPointer = ctypes.POINTER(EntityData)
    entities = CreateEntities(MAX_ENTITIES)
    NPC.activate(entities, EntityPointer, MAX_ENTITIES)

    playerContoroler = Contoroler_Key()
    seed = random.randint(0, 999999999)
    print("seed:", seed)

    if not Texture.init():
        print("Warning: one or more textures could not be loaded from the assets folder")

    world = World(seed)
    player = world.newPlayer(
        50,
        50,
        conster.WIDTH / 2 - 25,
        conster.HEIGHT / 2 - 25,
        Texture.npc1,
        playerContoroler,
    )
    print("game started")

    while conster.Render:
        if not world.update():
            break
        world.draw()

finally:
    Quit()
