import conster

from conster import *
import BlockManager as block_manager_module
import object as object_module
from BlockManager import *
from npc import *
from object import *
from camera import Camera
from cppfuncs import (
    Render as CPP_Render,
    present as CPP_Present,
    GetRenderer,
    getWinSize,
    DrawObj,
)


class World:

    def __init__(self, seed, display=None):
        self.npcs = {}
        self.player = None
        self.seed = seed
        self.display = display
        self.blockManager = BlocksWorld(seed)
        self.blockManager.create()
        self.camera = Camera(self.blockManager)

    def update(self):
        # SDL event polling must happen before reading SDL keyboard state.
        if not CPP_Render():
            return False

        width, height = getWinSize()
        if width > 0 and height > 0:
            self.camera.width = width
            self.camera.height = height
            block_manager_module.WIDTH = width
            block_manager_module.HEIGHT = height
            object_module.WIDTH = width
            object_module.HEIGHT = height

        self.blockManager.update_background_loading()

        for npc_id, (data, contoroler) in self.npcs.items():
            data.getAPI(contoroler.getAPI())
            data.update()

        if self.player:
            self.blockManager.move(-self.player.last_dx, self.player.last_dy)

        return True

    def draw(self):
        renderer = GetRenderer()
        self.blockManager.drawBlocks()

        # Objects are drawn by SDL3, in their existing Z order.
        for item in sorted(obj.objs.values(), key=lambda value: value.world_z):
            if item.is_visible(self.camera.x, self.camera.y):
                DrawObj(
                    renderer,
                    item.world_x + self.camera.x,
                    item.world_y + self.camera.y,
                    item.width,
                    item.height,
                    item.texture,
                )

        # NPC.color contains the SDL texture ID passed by main.py.
        for npc, _controller in self.npcs.values():
            if npc.is_visible(self.camera):
                DrawObj(
                    renderer,
                    npc.world_x + self.camera.x,
                    npc.world_y + self.camera.y,
                    npc.width,
                    npc.height,
                    npc.color,
                )

        CPP_Present()

    def get_frame_data(self):
        """
        همه‌ی چیزهایی که رندر C++ لازم دارد، فقط برای آنچه در دوربین است.
        """
        return {
            "camera": (self.camera.x, self.camera.y),
            "npcs": [n.to_render_data(self.camera)
                     for n in NPC.visible_npcs(self.camera)],
            "objects": obj.snapshot(self.camera.x, self.camera.y),
        }

    def newNPC(self, w, h, x, y, color, contoroler=None, player=False):
        if contoroler is None:
            contoroler = NPC_Contoroler()
        npc_id = len(self.npcs) + 1
        npc = NPC(w, h, x, y, self.display, self.blockManager, color, True, player)
        self.npcs[npc_id] = (npc, contoroler)
        if player:
            self.player = npc
        return npc

    def newPlayer(self, w, h, x, y, color, contoroler=None):
        return self.newNPC(w, h, x, y, color, contoroler, True)
